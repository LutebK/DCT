import cv2
import numpy as np
from scipy.fftpack import dct, idct
from tkinter import filedialog
from tkinter import Tk

# --- Zikzak Fonksiyonları ---
def zigzag_indices(size):
    indices = np.arange(size**2).reshape(size, size)
    result = np.concatenate([np.diagonal(indices[::-1], k)[::(2 * (k % 2) - 1)] for k in range(1 - size, size)])
    return result

def zigzag_scan(block):
    size = block.shape[0]
    indices = zigzag_indices(size)
    return block.flatten()[indices]

def inverse_zigzag(scan, size):
    indices = zigzag_indices(size)
    block = np.zeros((size, size))
    block.flat[indices] = scan
    return block

# --- Blok Bölme ve Birleştirme ---
def split_into_blocks(image, block_size=8):
    h, w = image.shape
    blocks = []
    for i in range(0, h, block_size):
        for j in range(0, w, block_size):
            blocks.append(image[i:i+block_size, j:j+block_size])
    return blocks

def merge_blocks(blocks, image_shape, block_size=8):
    h, w = image_shape
    reconstructed = np.zeros((h, w), dtype=np.float32)
    block_idx = 0
    for i in range(0, h, block_size):
        for j in range(0, w, block_size):
            block = blocks[block_idx]
            block = block[:block_size, :block_size]
            reconstructed[i:i+block.shape[0], j:j+block.shape[1]] = block
            block_idx += 1
    return np.clip(reconstructed, 0, 255).astype(np.uint8)

# --- DCT ve IDCT ---
def dct2(block):
    return dct(dct(block.T, norm='ortho').T, norm='ortho')

def idct2(block):
    return idct(idct(block.T, norm='ortho').T, norm='ortho')

# --- Su İşareti Gömme ---
def embed_watermark_zigzag_blocks(cover_image, watermark, alpha):
    cover_blocks = split_into_blocks(cover_image)
    watermark_bits = watermark.flatten() > 127  # Binarize su işareti

    watermarked_blocks = []
    for i, cover_block in enumerate(cover_blocks):
        if i < len(watermark_bits):
            wm_bit = watermark_bits[i]
            dct_cover_block = dct2(cover_block)
            zigzag = zigzag_scan(dct_cover_block)

            # 6-28 aralığını düzenle
            if wm_bit:
                zigzag[6:29] += alpha
            else:
                zigzag[6:29] -= alpha

            # Ters zikzak ve IDCT
            modified_block = idct2(inverse_zigzag(zigzag, cover_block.shape[0]))
            watermarked_blocks.append(modified_block)
        else:
            watermarked_blocks.append(cover_block)

    return merge_blocks(watermarked_blocks, cover_image.shape)

# --- Filigran Çıkarma ---
def extract_watermark_zigzag_blocks(watermarked_image, cover_image, watermark_size, alpha):
    cover_blocks = split_into_blocks(cover_image)
    watermarked_blocks = split_into_blocks(watermarked_image)

    extracted_bits = []
    for i in range(len(cover_blocks)):
        dct_cover_block = dct2(cover_blocks[i])
        dct_watermarked_block = dct2(watermarked_blocks[i])

        zigzag_cover = zigzag_scan(dct_cover_block)
        zigzag_watermarked = zigzag_scan(dct_watermarked_block)

        diff = zigzag_watermarked[6:29] - zigzag_cover[6:29]
        extracted_bits.append(1 if diff.sum() > 0 else 0)

    # Filigran yeniden oluştur
    watermark = np.array(extracted_bits[:watermark_size**2]).reshape((watermark_size, watermark_size)) * 255
    return watermark.astype(np.uint8)

# --- PSNR Hesaplama ---
def calculate_psnr(original, watermarked):
    mse = np.mean((original - watermarked) ** 2)
    if mse == 0:
        return 100
    max_pixel = 255.0
    psnr = 20 * np.log10(max_pixel / np.sqrt(mse))
    return psnr

# --- NC Hesaplama ---
def calculate_nc(original_watermark, extracted_watermark):
    original_flat = original_watermark.flatten()
    extracted_flat = extracted_watermark.flatten()
    numerator = np.sum(original_flat * extracted_flat)
    denominator = np.sqrt(np.sum(original_flat ** 2) * np.sum(extracted_flat ** 2))
    return numerator / denominator

# --- Ataklar ---
def apply_attack(image, attack_type):
    if attack_type == "jpeg":
        cv2.imwrite("jpeg_compressed.jpg", image, [cv2.IMWRITE_JPEG_QUALITY, 50])
        return cv2.imread("jpeg_compressed.jpg", cv2.IMREAD_GRAYSCALE)
    elif attack_type == "blur":
        return cv2.GaussianBlur(image, (5, 5), 0)
    elif attack_type == "noise":
        noise = np.random.normal(0, 10, image.shape).astype(np.uint8)
        return cv2.add(image, noise)
    else:
        raise ValueError("Unknown attack type.")

# --- Ana Kod ---
if __name__ == "__main__":
    root = Tk()
    root.withdraw()
    cover_path = filedialog.askopenfilename(title="Kapak görüntüsü seçin", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg")])
    watermark_path = filedialog.askopenfilename(title="Su işareti görüntüsü seçin", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg")])

    cover_image = cv2.imread(cover_path, cv2.IMREAD_GRAYSCALE)
    h, w = cover_image.shape
    h = (h // 8) * 8
    w = (w // 8) * 8
    cover_image = cover_image[:h, :w]

    watermark = cv2.imread(watermark_path, cv2.IMREAD_GRAYSCALE)
    watermark = cv2.resize(watermark, (64, 64))  # Su işareti boyutunu 64x64 olarak ayarla

    alpha = 0.1
    watermarked_image = embed_watermark_zigzag_blocks(cover_image, watermark, alpha)
    extracted_watermark = extract_watermark_zigzag_blocks(watermarked_image, cover_image, 64, alpha)

    psnr = calculate_psnr(cover_image, watermarked_image)
    nc_original = calculate_nc(watermark, extracted_watermark)

    # Ataklar ve NC hesaplamaları
    attacks = ["jpeg", "blur", "noise"]
    nc_attacked = {}

    for attack in attacks:
        attacked_image = apply_attack(watermarked_image, attack)
        extracted_watermark_attacked = extract_watermark_zigzag_blocks(attacked_image, cover_image, 64, alpha)
        nc_attacked[attack] = calculate_nc(watermark, extracted_watermark_attacked)

    # Sonuçları kaydet ve yazdır
    cv2.imwrite("original_cover_image.jpg", cover_image)
    cv2.imwrite("watermarked_image.jpg", watermarked_image)
    cv2.imwrite("extracted_watermark.jpg", extracted_watermark)

    print(f"PSNR: {psnr:.2f} dB")
    print(f"NC (Original): {nc_original:.4f}")
    for attack, nc in nc_attacked.items():
        print(f"NC (Attack: {attack}): {nc:.4f}")
    print("Çıktılar: 'original_cover_image.jpg', 'watermarked_image.jpg', 'extracted_watermark.jpg'")
